# Lemonate-App-Android-Kotlin
The lemonade app is just a simple android app to learn kotlin and android basics. Basically, the app code contains the state machine logic.

![2021-09-01 21_21_21-Android Emulator - Pixel_3a_API_30_x86_5554](https://user-images.githubusercontent.com/36234545/131724053-a9820f52-748b-4121-9f6b-f74f12a0c1ee.png)

![2021-09-01 21_21_32-shtanriverdi_Lemonate-App-Android-Kotlin_ The lemonade app is just a simple andr](https://user-images.githubusercontent.com/36234545/131724041-1b609833-5c89-446e-bb40-2c1bc11f252b.png)
